import { Facebook, Instagram, Mail, MapPin, Phone, Youtube } from "lucide-react";
import { PHONE_DISPLAY, wa } from "@/lib/contact";
import { BRAND } from "@/lib/images";

export function Footer() {
  return (
    <footer className="bg-navy text-white pt-20 pb-10 relative overflow-hidden">
      <div className="absolute inset-0 islamic-pattern opacity-20 pointer-events-none" />
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />

      <div className="relative mx-auto max-w-7xl px-6 grid lg:grid-cols-4 gap-10">
        <div className="lg:col-span-1">
          <img
            src={BRAND.logo}
            alt="Logo Sai Tour Umroh & Haji"
            loading="lazy"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
            className="h-12 md:h-14 w-auto object-contain mb-5"
          />
          <div className="flex items-center gap-3">
            <span className="grid place-items-center w-11 h-11 rounded-full gradient-gold">
              <span className="font-display text-navy text-xl font-bold leading-none">S</span>
            </span>
            <div>
              <p className="font-display text-xl">Sai Tour</p>
              <p className="text-[10px] tracking-[0.25em] uppercase text-gold">Umroh & Haji</p>
            </div>
          </div>
          <p className="mt-5 text-sm text-white/65 leading-relaxed">
            Pendamping ibadah umroh terpercaya untuk keluarga muslim Indonesia.
            Umroh menjadi mudah, doa-doa terijabah.
          </p>
          <div className="flex gap-3 mt-6">
            {[Instagram, Facebook, Youtube, Mail].map((Icon, i) => (
              <a
                key={i}
                href="#"
                aria-label="Social media"
                className="grid place-items-center w-10 h-10 rounded-full border border-white/15 text-white/80 hover:bg-gold hover:text-navy hover:border-gold transition-colors"
              >
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-display text-lg text-gold mb-4">Menu</h4>
          <ul className="space-y-2.5 text-sm text-white/75">
            <li><a href="#home" className="hover:text-gold transition-colors">Home</a></li>
            <li><a href="#profil" className="hover:text-gold transition-colors">Profil</a></li>
            <li><a href="#legalitas" className="hover:text-gold transition-colors">Legalitas</a></li>
            <li><a href="#jadwal" className="hover:text-gold transition-colors">Jadwal</a></li>
            <li>
              <a
                href={wa("Assalamualaikum, saya ingin bertanya.")}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-gold transition-colors"
              >
                Hubungi Kami
              </a>
            </li>
          </ul>
        </div>

        <div className="lg:col-span-1">
          <h4 className="font-display text-lg text-gold mb-4">Alamat</h4>
          <p className="text-sm text-white/75 leading-relaxed flex gap-3">
            <MapPin size={18} className="text-gold shrink-0 mt-0.5" />
            <span>
              Jl. Jogja-Solo Km. 8,5 Onggomertan RT.07 RW.26 Nayan,
              Maguwoharjo, Depok, Sleman, DI Yogyakarta
            </span>
          </p>
        </div>

        <div>
          <h4 className="font-display text-lg text-gold mb-4">Kontak</h4>
          <ul className="space-y-3 text-sm text-white/75">
            <li className="flex gap-3 items-center">
              <Phone size={16} className="text-gold" />
              <a
                href={wa("Assalamualaikum, saya ingin bertanya tentang umroh.")}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-gold transition-colors"
              >
                {PHONE_DISPLAY}
              </a>
            </li>
            <li className="flex gap-3 items-center">
              <Mail size={16} className="text-gold" />
              <span>info@saitour.id</span>
            </li>
          </ul>
          <a
            href={wa("Assalamualaikum, saya ingin konsultasi umroh.")}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-full gradient-gold text-navy text-sm font-semibold"
          >
            Chat WhatsApp
          </a>
        </div>
      </div>

      <div className="relative mx-auto max-w-7xl px-6 mt-14 pt-6 border-t border-white/10 flex flex-col sm:flex-row gap-3 items-center justify-between text-xs text-white/50">
        <p>© {new Date().getFullYear()} Sai Tour Umroh & Haji — Agen Lina. All rights reserved.</p>
        <p>Crafted with ♥ for setiap langkah menuju Baitullah</p>
      </div>
    </footer>
  );
}
