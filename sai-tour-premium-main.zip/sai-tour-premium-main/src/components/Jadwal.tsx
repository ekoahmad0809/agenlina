import { wa } from "@/lib/contact";
import { ArrowUpRight } from "lucide-react";

const flyers = [
  { src: "https://umrohsaitour.com/assets/jadwal-2026-DUmsM3zc.jpeg", label: "Umroh Ramadhan 2026" },
  { src: "https://umrohsaitour.com/assets/Umroh-milad-WP_fDlCd.jpeg", label: "Umroh Akhir Tahun 2026" },
  { src: "https://umrohsaitour.com/assets/Umroh-singapore-CaKkYqB_.jpeg", label: "Umroh Hemat Maret 2026" },
  { src: "https://umrohsaitour.com/assets/Umroh-bahagia-C5WaFPRM.jpeg", label: "Umroh Plus Turki 2026" },
  { src: "https://umrohsaitour.com/assets/Umroh-milad-WP_fDlCd.jpeg", label: "Umroh VIP Eksekutif 2026" },
  { src: "https://umrohsaitour.com/assets/jadwal-2026-DUmsM3zc.jpeg", label: "Haji Plus 2027" },
];

export function Jadwal() {
  return (
    <section
      id="jadwal"
      className="relative py-24 lg:py-32 overflow-hidden bg-gradient-to-b from-cream via-background to-cream"
    >
      <div className="absolute inset-0 islamic-pattern opacity-50 pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto reveal">
          <span className="text-xs tracking-[0.3em] uppercase text-gold font-medium">
            Jadwal Resmi
          </span>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl text-navy leading-tight">
            Jadwal Keberangkatan <span className="italic text-gold">Umroh</span>
          </h2>
          <p className="mt-5 text-navy/65 leading-relaxed">
            Pilih jadwal terbaik sesuai kebutuhan perjalanan ibadah Anda. Kuota
            terbatas — amankan keberangkatan Anda lebih awal.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {flyers.map((f, i) => (
            <div
              key={i}
              className="reveal group relative rounded-3xl overflow-hidden bg-white shadow-soft hover:shadow-luxe transition-all border border-[oklch(0.88_0.02_80/0.6)]"
            >
              <div className="overflow-hidden aspect-[3/4] bg-navy">
                <img
                  src={f.src}
                  alt={f.label}
                  loading="lazy"
                  width={1024}
                  height={1536}
                  className="w-full h-full object-cover group-hover:scale-[1.06] transition-transform duration-[900ms] ease-out"
                />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-navy/95 via-navy/50 to-transparent">
                <div className="flex items-end justify-between gap-3">
                  <div>
                    <p className="text-[10px] tracking-[0.3em] uppercase text-gold">Keberangkatan</p>
                    <p className="font-display text-xl text-white mt-0.5 leading-snug">{f.label}</p>
                  </div>
                  <a
                    href={wa(`Assalamualaikum, saya ingin info paket ${f.label}.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Info ${f.label}`}
                    className="grid place-items-center w-10 h-10 shrink-0 rounded-full gradient-gold text-navy hover:scale-110 transition-transform"
                  >
                    <ArrowUpRight size={18} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-14 text-center reveal">
          <a
            href={wa("Assalamualaikum, saya ingin info jadwal lengkap umroh.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full gradient-gold text-navy font-semibold shadow-luxe hover:scale-[1.03] transition-transform"
          >
            Info Jadwal Lengkap
            <ArrowUpRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}
