import { images } from "@/lib/images";
const jamaahImg = images.jamaahBaitullah;

export function Jamaah() {
  return (
    <section className="relative py-24 lg:py-32 bg-background overflow-hidden">
      <div className="absolute inset-0 islamic-pattern opacity-60 pointer-events-none" />

      <div className="relative mx-auto max-w-5xl px-6 text-center reveal">
        <p className="font-display text-2xl sm:text-3xl lg:text-4xl text-navy leading-snug italic">
          “Allah tidak <span className="text-gold not-italic font-semibold">MEMANGGIL</span> orang-orang yang{" "}
          <span className="text-gold not-italic font-semibold">MAMPU</span>, tapi Allah{" "}
          <span className="text-gold not-italic font-semibold">MEMAMPUKAN</span> orang-orang yang{" "}
          <span className="text-gold not-italic font-semibold">TERPANGGIL</span> untuk berkunjung ke Baitullah (Ka'bah).”
        </p>
      </div>

      <div className="relative mx-auto max-w-6xl px-6 mt-14 reveal">
        <div className="rounded-3xl overflow-hidden shadow-luxe relative">
          <img
            src={jamaahImg}
            alt="Jamaah tawaf di Baitullah"
            loading="lazy"
            width={1920}
            height={1080}
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src =
                "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=1920&q=80";
            }}
            className="w-full h-[260px] sm:h-[400px] lg:h-[520px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-navy/30 to-transparent pointer-events-none" />
        </div>
      </div>

      <div className="relative mx-auto max-w-3xl px-6 mt-14 reveal">
        <p className="text-navy/75 leading-[1.9] text-base lg:text-lg">
          Allah SWT menjadikan Baitullah sebagai tempat untuk dikunjungi umat
          Islam di seluruh dunia pada setiap tahunnya. Dalam{" "}
          <strong className="text-navy">QS. Al Baqarah ayat 125</strong>:
        </p>

        <div
          dir="rtl"
          lang="ar"
          className="mt-8 p-7 lg:p-10 rounded-3xl bg-cream border border-gold/30 text-navy text-2xl lg:text-3xl leading-[2.2] text-right font-medium shadow-soft"
          style={{ fontFamily: "'Amiri', 'Cormorant Garamond', serif" }}
        >
          وَإِذْ جَعَلْنَا ٱلْبَيْتَ مَثَابَةً لِّلنَّاسِ وَأَمْنًا وَٱتَّخِذُوا۟ مِن مَّقَامِ إِبْرَٰهِۦمَ مُصَلًّى ۖ وَعَهِدْنَآ إِلَىٰٓ إِبْرَٰهِۦمَ وَإِسْمَٰعِيلَ أَن طَهِّرَا بَيْتِىَ لِلطَّآئِفِينَ وَٱلْعَٰكِفِينَ وَٱلرُّكَّعِ ٱلسُّجُودِ
        </div>

        <p className="mt-8 text-navy/75 leading-[1.9] text-base lg:text-lg">
          <strong className="text-navy">Artinya:</strong> “Dan (ingatlah),
          ketika Kami menjadikan rumah itu (Baitullah) tempat berkumpul bagi
          manusia dan tempat yang aman. Dan jadikanlah sebahagian maqam Ibrahim
          tempat shalat. Dan telah Kami perintahkan kepada Ibrahim dan Ismail:
          ‘Bersihkanlah rumah-Ku untuk orang-orang yang thawaf, yang i'tikaf,
          yang ruku' dan yang sujud’.” <em className="text-gold">(QS. Al Baqarah: 125)</em>.
        </p>
      </div>
    </section>
  );
}
