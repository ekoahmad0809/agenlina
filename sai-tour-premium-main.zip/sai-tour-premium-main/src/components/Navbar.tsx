import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { wa } from "@/lib/contact";
import { BRAND } from "@/lib/images";

const links = [
  { label: "Home", href: "#home" },
  { label: "Profil", href: "#profil" },
  { label: "Legalitas", href: "#legalitas" },
  { label: "Jadwal", href: "#jadwal" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "py-3 bg-[oklch(0.21_0.04_260/0.85)] backdrop-blur-xl border-b border-[oklch(1_0_0/0.06)]"
          : "py-5 bg-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-6 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-3 group">
          <img
            src={BRAND.logo}
            alt="Logo Sai Tour Umroh & Haji"
            loading="eager"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
            className="h-8 md:h-10 w-auto object-contain drop-shadow"
          />
          <span className="grid place-items-center w-10 h-10 rounded-full gradient-gold shadow-glow-gold">
            <span className="font-display text-navy text-xl font-bold leading-none">S</span>
          </span>
          <span className="leading-tight">
            <span className="block font-display text-lg text-white">Sai Tour</span>
            <span className="block text-[10px] tracking-[0.25em] uppercase text-gold">
              Umroh & Haji
            </span>
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-9">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-white/85 hover:text-gold transition-colors relative after:content-[''] after:absolute after:left-0 after:-bottom-1 after:h-px after:w-0 after:bg-gold after:transition-all hover:after:w-full"
            >
              {l.label}
            </a>
          ))}
          <a
            href={wa("Assalamualaikum, saya ingin konsultasi umroh dengan Agen Lina.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full gradient-gold text-navy text-sm font-semibold shadow-glow-gold hover:scale-105 transition-transform"
          >
            Hubungi Kami
          </a>
        </nav>

        <button
          aria-label="Toggle menu"
          className="lg:hidden text-white p-2"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden mx-6 mt-3 rounded-2xl glass-dark p-6 animate-fade-in">
          <nav className="flex flex-col gap-4">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-white/90 hover:text-gold transition-colors"
              >
                {l.label}
              </a>
            ))}
            <a
              href={wa("Assalamualaikum, saya ingin konsultasi umroh dengan Agen Lina.")}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full gradient-gold text-navy text-sm font-semibold"
            >
              Hubungi Kami
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
