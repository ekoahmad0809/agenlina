import { images } from "@/lib/images";
const agenImg = images.agenLina;
import { Heart, Users, Sparkles, MessageCircle, ShieldCheck } from "lucide-react";

const features = [
  { icon: Sparkles, title: "Pengalaman Bertahun-tahun", desc: "Telah memberangkatkan ratusan jamaah dengan ibadah yang khusyuk dan berkesan." },
  { icon: Heart, title: "Pelayanan Ramah & Terpercaya", desc: "Setiap jamaah dilayani sepenuh hati seperti keluarga sendiri." },
  { icon: Users, title: "Pendampingan Jamaah", desc: "Bimbingan manasik dan pendampingan langsung selama ibadah di tanah suci." },
  { icon: MessageCircle, title: "Konsultasi Fleksibel", desc: "Konsultasi gratis kapan saja melalui WhatsApp atau bertemu langsung." },
];

const stats = [
  { value: "500+", label: "Jamaah Berangkat" },
  { value: "10+", label: "Tahun Pengalaman" },
  { value: "100%", label: "Konsultasi Gratis" },
];

export function Profil() {
  return (
    <section id="profil" className="relative py-24 lg:py-36 bg-cream overflow-hidden">
      <div className="absolute inset-0 islamic-pattern opacity-60 pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-14 lg:gap-20 items-center">
        {/* Image */}
        <div className="reveal relative">
          <div className="absolute -top-6 -left-6 w-32 h-32 rounded-full gradient-gold blur-3xl opacity-40" />
          <div className="absolute -bottom-8 -right-8 w-40 h-40 rounded-full bg-navy/10 blur-3xl" />
          <div className="relative rounded-[2rem] overflow-hidden shadow-luxe border border-white">
            <img
              src={agenImg}
              alt="Agen Lina — pendamping ibadah umroh"
              loading="lazy"
              width={1024}
              height={1280}
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  "https://images.unsplash.com/photo-1564769662533-4f00a87b4056?w=1024&q=80";
              }}
              className="w-full h-auto object-cover aspect-[4/5]"
            />
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-navy/90 via-navy/40 to-transparent">
              <p className="text-gold text-xs tracking-[0.3em] uppercase">Agen Resmi</p>
              <p className="font-display text-3xl text-white mt-1">Agen Lina</p>
            </div>
          </div>
          <div className="absolute -right-4 top-10 hidden md:flex flex-col items-center glass rounded-2xl px-5 py-4 shadow-soft">
            <ShieldCheck className="text-gold" size={24} />
            <span className="text-[10px] uppercase tracking-widest mt-1 text-navy/70">Terpercaya</span>
          </div>
        </div>

        {/* Content */}
        <div className="reveal">
          <span className="inline-block text-xs tracking-[0.3em] uppercase text-gold font-medium">
            Tentang Agen Lina
          </span>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-[3.75rem] leading-[1.05] text-navy">
            Mendampingi ibadah Anda dengan <span className="italic text-gold">amanah & ketulusan</span>
          </h2>
          <p className="mt-6 text-base lg:text-lg text-navy/70 leading-relaxed">
            Bersama <strong className="text-navy">Sai Tour Umroh & Haji</strong>, Agen Lina
            telah dipercaya keluarga muslim Indonesia untuk perjalanan ibadah ke
            Baitullah. Setiap jamaah didampingi sejak persiapan hingga kembali
            ke tanah air dengan pelayanan yang ramah, profesional, dan penuh
            ketulusan.
          </p>

          <div className="mt-10 grid sm:grid-cols-2 gap-5">
            {features.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl bg-white/80 border border-[oklch(0.88_0.02_80/0.7)] p-5 shadow-soft hover:shadow-luxe transition-shadow"
              >
                <span className="grid place-items-center w-10 h-10 rounded-xl gradient-gold mb-3">
                  <f.icon size={18} className="text-navy" />
                </span>
                <h3 className="font-display text-xl text-navy">{f.title}</h3>
                <p className="text-sm text-navy/65 mt-1.5 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-10 grid grid-cols-3 gap-4">
            {stats.map((s) => (
              <div
                key={s.label}
                className="rounded-2xl bg-navy text-center px-3 py-6 shadow-luxe relative overflow-hidden"
              >
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
                <p className="font-display text-3xl lg:text-4xl gold-text-gradient">{s.value}</p>
                <p className="text-[10px] sm:text-xs uppercase tracking-widest text-white/70 mt-1.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
