import { images } from "@/lib/images";

const photos = images.testimoni;

export function Galeri() {
  const loop = [...photos, ...photos];
  return (
    <section className="py-24 lg:py-32 bg-cream overflow-hidden">
      <div className="mx-auto max-w-3xl px-6 text-center reveal">
        <span className="text-xs tracking-[0.3em] uppercase text-gold font-medium">
          Cerita Jamaah
        </span>
        <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl text-navy leading-tight">
          Testimoni <span className="italic text-gold">Jamaah</span>
        </h2>
        <p className="mt-5 text-navy/65 leading-relaxed">
          Senyum bahagia jamaah yang telah menyempurnakan ibadah umroh bersama
          Agen Lina dan Sai Tour Umroh & Haji.
        </p>
      </div>

      <div className="mt-16 group relative">
        {/* fade edges */}
        <div className="pointer-events-none absolute inset-y-0 left-0 w-24 sm:w-40 bg-gradient-to-r from-cream to-transparent z-10" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-24 sm:w-40 bg-gradient-to-l from-cream to-transparent z-10" />

        <div
          className="flex gap-6 lg:gap-8 w-max animate-marquee group-hover:[animation-play-state:paused]"
        >
          {loop.map((src, i) => (
            <figure
              key={i}
              className="relative w-[260px] sm:w-[320px] lg:w-[360px] aspect-square rounded-3xl overflow-hidden shadow-luxe border border-white"
            >
              <img
                src={src}
                alt={`Testimoni jamaah ${i % photos.length + 1}`}
                loading="lazy"
                width={800}
                height={800}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=800&q=80";
                }}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/50 via-transparent to-transparent" />
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
