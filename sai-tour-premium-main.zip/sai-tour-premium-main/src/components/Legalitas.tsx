
const items = [
  { src: "https://umrohsaitour.com/assets/sertifikat-1-CSLWtobM.jpeg", title: "Izin Resmi Travel", desc: "Terdaftar sebagai biro perjalanan ibadah umroh resmi." },
  { src: "https://umrohsaitour.com/assets/sertifikat-2-9uhkt_8V.jpeg", title: "Akreditasi Kementerian Agama", desc: "Diakui dan diawasi sesuai regulasi pemerintah." },
];

export function Legalitas() {
  return (
    <section id="legalitas" className="relative py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto reveal">
          <span className="text-xs tracking-[0.3em] uppercase text-gold font-medium">
            Legalitas Resmi
          </span>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl text-navy leading-tight">
            Legalitas & <span className="italic text-gold">Kepercayaan</span>
          </h2>
          <p className="mt-5 text-navy/65 leading-relaxed">
            Kami berkomitmen memberikan ketenangan kepada jamaah melalui
            transparansi dokumen perizinan dan sertifikasi resmi yang terpercaya.
          </p>
        </div>

        <div className="mt-16 grid md:grid-cols-2 gap-8">
          {items.map((it, i) => (
            <div
              key={i}
              className="reveal group relative rounded-3xl overflow-hidden bg-white border border-[oklch(0.88_0.02_80)] shadow-soft hover:shadow-luxe transition-all"
            >
              <div className="overflow-hidden aspect-[4/3] bg-cream">
                <img
                  src={it.src}
                  alt={it.title}
                  loading="lazy"
                  width={1024}
                  height={768}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                />
              </div>
              <div className="p-6 lg:p-7 border-t border-[oklch(0.88_0.02_80)]">
                <div className="flex items-center gap-3">
                  <span className="h-px w-8 bg-gold" />
                  <span className="text-xs tracking-[0.25em] uppercase text-gold">Dokumen Resmi</span>
                </div>
                <h3 className="mt-3 font-display text-2xl text-navy">{it.title}</h3>
                <p className="mt-2 text-sm text-navy/65 leading-relaxed">{it.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
