import { images } from "@/lib/images";
const heroImg = images.hero;
import { wa } from "@/lib/contact";
import { ArrowRight, Calendar } from "lucide-react";

export function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen w-full overflow-hidden flex items-center"
    >
      <img
        src={heroImg}
        alt="Jamaah umroh tawaf di sekitar Kabah"
        width={1920}
        height={1280}
        loading="eager"
        onError={(e) => {
          (e.currentTarget as HTMLImageElement).src =
            "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=1920&q=80";
        }}
        className="absolute inset-0 w-full h-full object-cover scale-105"
      />
      <div className="absolute inset-0 gradient-hero-overlay" />

      {/* Floating lights */}
      <div className="pointer-events-none absolute inset-0">
        <span className="absolute top-1/4 left-[15%] w-2 h-2 rounded-full bg-gold/70 blur-[1px] animate-float" />
        <span
          className="absolute top-1/3 right-[20%] w-3 h-3 rounded-full bg-[oklch(0.92_0.06_85/0.6)] blur-[2px] animate-float"
          style={{ animationDelay: "1.5s" }}
        />
        <span
          className="absolute bottom-1/3 left-[30%] w-1.5 h-1.5 rounded-full bg-gold/60 blur-[1px] animate-float"
          style={{ animationDelay: "3s" }}
        />
        <span
          className="absolute top-[60%] right-[10%] w-2 h-2 rounded-full bg-gold/50 blur-[1px] animate-float"
          style={{ animationDelay: "2s" }}
        />
        <span
          className="absolute bottom-1/4 right-[35%] w-1 h-1 rounded-full bg-[oklch(0.92_0.06_85/0.7)] animate-float"
          style={{ animationDelay: "4s" }}
        />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6 pt-32 pb-24 w-full">
        <div className="max-w-3xl">
          <span
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-dark text-gold text-xs tracking-[0.3em] uppercase animate-fade-up"
            style={{ animationDelay: "0.1s" }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-gold" />
            Sai Tour Umroh & Haji
          </span>

          <h1
            className="mt-7 font-display text-5xl sm:text-6xl lg:text-7xl xl:text-[5.5rem] leading-[1.05] text-white animate-fade-up"
            style={{ animationDelay: "0.25s" }}
          >
            Umroh Menjadi Mudah, <br />
            <span className="gold-text-gradient italic">Doa-doa Terijabah</span>
          </h1>

          <p
            className="mt-7 max-w-xl text-base sm:text-lg text-white/80 leading-relaxed animate-fade-up"
            style={{ animationDelay: "0.4s" }}
          >
            Pendampingan ibadah umroh terpercaya untuk keluarga muslim Indonesia.
            Bersama Agen Lina, perjalanan suci Anda menjadi tenang, nyaman, dan
            penuh berkah.
          </p>

          <div
            className="mt-10 flex flex-wrap gap-4 animate-fade-up"
            style={{ animationDelay: "0.55s" }}
          >
            <a
              href={wa("Assalamualaikum, saya ingin konsultasi umroh dengan Agen Lina.")}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2.5 px-7 py-4 rounded-full gradient-gold text-navy font-semibold shadow-luxe hover:scale-[1.03] transition-transform"
            >
              Konsultasi Umroh
              <ArrowRight
                size={18}
                className="group-hover:translate-x-1 transition-transform"
              />
            </a>
            <a
              href="#jadwal"
              className="inline-flex items-center gap-2.5 px-7 py-4 rounded-full glass text-white border border-white/20 font-medium hover:bg-white/10 transition-colors"
            >
              <Calendar size={18} className="text-gold" />
              Lihat Jadwal
            </a>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-fade-in">
        <div className="w-[1px] h-12 bg-gradient-to-b from-transparent via-gold to-transparent" />
      </div>
    </section>
  );
}
