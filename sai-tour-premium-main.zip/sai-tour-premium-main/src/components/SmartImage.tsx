import { useState, type ImgHTMLAttributes } from "react";
import { cn } from "@/lib/utils";
import { FALLBACK_IMAGE } from "@/lib/images";

interface SmartImageProps extends ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  fallback?: string;
  wrapperClassName?: string;
}

export function SmartImage({
  src,
  alt,
  fallback = FALLBACK_IMAGE,
  className,
  wrapperClassName,
  loading = "lazy",
  ...rest
}: SmartImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [errored, setErrored] = useState(false);
  const finalSrc = errored ? fallback : src;

  return (
    <span className={cn("relative block w-full h-full overflow-hidden", wrapperClassName)}>
      {!loaded && (
        <span
          aria-hidden
          className="absolute inset-0 animate-pulse bg-[oklch(0.92_0.02_80)]"
        />
      )}
      <img
        {...rest}
        src={finalSrc}
        alt={alt}
        loading={loading}
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => {
          setErrored(true);
          setLoaded(true);
        }}
        className={cn(
          "transition-opacity duration-500",
          loaded ? "opacity-100" : "opacity-0",
          className,
        )}
      />
    </span>
  );
}
