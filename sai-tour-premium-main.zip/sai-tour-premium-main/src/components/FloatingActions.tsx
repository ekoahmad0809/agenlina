import { useEffect, useState } from "react";
import { ArrowUp, MessageCircle, X } from "lucide-react";
import { wa } from "@/lib/contact";

export function FloatingActions() {
  const [show, setShow] = useState(false);
  const [showBubble, setShowBubble] = useState(false);
  const [bubbleClosed, setBubbleClosed] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setShowBubble(true), 5000);
    return () => clearTimeout(t);
  }, []);

  return (
    <>
      {/* Back to top — bottom left */}
      <button
        type="button"
        aria-label="Kembali ke atas"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className={`fixed bottom-6 left-6 z-40 grid place-items-center w-12 h-12 rounded-full bg-navy text-gold shadow-luxe border border-gold/40 transition-all duration-500 ${
          show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
        }`}
      >
        <ArrowUp size={18} />
      </button>

      {/* WhatsApp + bubble — bottom right */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
        {showBubble && !bubbleClosed && (
          <div className="relative max-w-[260px] rounded-2xl bg-white shadow-luxe p-4 pr-9 border border-[oklch(0.88_0.02_80)] animate-popup-in">
            <button
              aria-label="Tutup"
              onClick={() => setBubbleClosed(true)}
              className="absolute top-2 right-2 text-navy/40 hover:text-navy"
            >
              <X size={14} />
            </button>
            <p className="text-[11px] tracking-[0.2em] uppercase text-gold font-semibold">
              Agen Syiar Lina
            </p>
            <p className="text-sm text-navy mt-1 leading-snug">
              Bisa kami bantu? 😊
            </p>
            <span className="absolute -bottom-2 right-6 w-3 h-3 rotate-45 bg-white border-r border-b border-[oklch(0.88_0.02_80)]" />
          </div>
        )}

        <a
          href={wa("Assalamualaikum, saya ingin konsultasi umroh dengan Agen Lina.")}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat WhatsApp Agen Lina"
          className="relative grid place-items-center w-14 h-14 rounded-full bg-[#25D366] text-white shadow-luxe hover:scale-110 transition-transform"
        >
          <MessageCircle size={24} fill="currentColor" />
          <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-30" />
        </a>
      </div>
    </>
  );
}
