import { wa } from "@/lib/contact";
import { ArrowRight } from "lucide-react";

export function CtaSection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 gradient-gold-navy" />
      <div
        className="absolute inset-0 opacity-30 mix-blend-overlay pointer-events-none"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><g fill='none' stroke='white' stroke-opacity='0.4' stroke-width='1'><path d='M60 0 L120 60 L60 120 L0 60 Z'/><circle cx='60' cy='60' r='28'/><circle cx='60' cy='60' r='44'/></g></svg>\")",
        }}
      />
      <div className="absolute -top-20 -left-20 w-96 h-96 rounded-full bg-gold/30 blur-3xl" />
      <div className="absolute -bottom-20 -right-20 w-96 h-96 rounded-full bg-gold/20 blur-3xl" />

      <div className="relative mx-auto max-w-4xl px-6 text-center reveal">
        <span className="text-xs tracking-[0.3em] uppercase text-gold font-medium">
          Saatnya Memenuhi Panggilan
        </span>
        <h2 className="mt-5 font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white leading-[1.1]">
          Siapkan perjalanan terbaik menuju{" "}
          <span className="gold-text-gradient italic">Baitullah</span> bersama
          Agen Lina
        </h2>
        <p className="mt-6 text-white/75 max-w-xl mx-auto leading-relaxed">
          Konsultasikan rencana ibadah Anda secara gratis. Kami siap membantu
          memilih paket terbaik untuk Anda dan keluarga.
        </p>
        <div className="mt-10 flex justify-center">
          <a
            href={wa("Assalamualaikum, saya ingin konsultasi sekarang dengan Agen Lina.")}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-3 px-8 py-4 rounded-full bg-white text-navy font-semibold shadow-luxe hover:scale-[1.04] transition-transform"
          >
            Konsultasi Sekarang
            <ArrowRight
              size={18}
              className="text-gold group-hover:translate-x-1 transition-transform"
            />
          </a>
        </div>
      </div>
    </section>
  );
}
