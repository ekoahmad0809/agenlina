import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Navbar } from '@/components/Navbar'
import { Hero } from '@/components/Hero'
import { Profil } from '@/components/Profil'
import { Legalitas } from '@/components/Legalitas'
import { Jadwal } from '@/components/Jadwal'
import { Jamaah } from '@/components/Jamaah'
import { Galeri } from '@/components/Galeri'
import { CtaSection } from '@/components/CtaSection'
import { Footer } from '@/components/Footer'
import { FloatingActions } from '@/components/FloatingActions'
import { useReveal } from '@/hooks/use-reveal'

const queryClient = new QueryClient()

function LandingPage() {
  useReveal()
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main>
        <Hero />
        <Profil />
        <Legalitas />
        <Jadwal />
        <Jamaah />
        <Galeri />
        <CtaSection />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LandingPage />
    </QueryClientProvider>
  )
}
