// Centralized external image URLs (CDN). Replace anytime.
export const BRAND = {
  logo: "https://umrohsaitour.com/assets/logo-saitour.png",
  favicon: "https://umrohsaitour.com/favicon.png",
};

export const FALLBACK_IMAGE =
  "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=1200&q=80";

export const images = {
  hero: "https://umrohsaitour.com/assets/hero-umroh-CK7nQfQp.jpeg",
  agenLina: "https://umrohsaitour.com/assets/agen-lina-D8mP3xYr.jpeg",
  jamaahBaitullah:
    "https://umrohsaitour.com/assets/jamaah-baitullah-Bw5LkPnT.jpeg",
  testimoni: [
    "https://umrohsaitour.com/assets/testimoni-1-CtX4mNqK.jpeg",
    "https://umrohsaitour.com/assets/testimoni-2-DpL9vRsM.jpeg",
    "https://umrohsaitour.com/assets/testimoni-3-Bk2HwQnP.jpeg",
    "https://umrohsaitour.com/assets/testimoni-4-Cm7JxYbV.jpeg",
    "https://umrohsaitour.com/assets/testimoni-5-Dn8KzRwL.jpeg",
  ],
};
