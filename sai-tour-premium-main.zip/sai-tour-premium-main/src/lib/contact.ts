export const PHONE_DISPLAY = "0813-2945-9323";
export const WHATSAPP_NUMBER = "6281329459323";
export const wa = (msg: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
